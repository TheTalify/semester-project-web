import React from 'react'

const Artisan = () => {
  return (
    <div>Artisan</div>
  )
}
export default Artisan