import React from 'react'

const KuchOr = () => {
  return (
    <div>KuchOr</div>
  )
}
export default KuchOr