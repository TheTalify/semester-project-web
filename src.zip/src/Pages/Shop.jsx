import React from 'react'

const Shop = () => {
  return (
    <div>Shop-All</div>
  )
}
export default Shop