import p1_img from './p1.jpeg'
import p2_img from './p2.jpeg'
import p3_img from './p3.jpeg'
import p4_img from './p4.jpeg'

let data_product = [
    {
        id:1,
        name:"Beats Studio 2.0 Beats Electronics Noise Cancelling Headphones",
        image:p1_img,
        new_price:4499,
        old_price:5000, 
    },
    {
        id:2,
        name:"Hydrating Cleanser For Dry To Normal Skin CeraVe",
        image:p2_img,
        new_price:2749,
        old_price:3200, 
    },
    {
        id:3,
        name:"Remote Control RC JEEP For Kids Dusty Green",
        image:p3_img,
        new_price:6000,
        old_price:8000, 
    },
    {
        id:4,
        name:"Floral Printed Soft Net Summers Lining Knees Frock",
        image:p4_img,
        new_price:5999.00,
        old_price:7899.00, 
    },

];
export default data_product;
